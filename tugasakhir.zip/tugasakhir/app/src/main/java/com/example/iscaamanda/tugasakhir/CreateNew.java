package com.example.iscaamanda.tugasakhir;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;
import android.widget.EditText;

public class CreateNew extends AppCompatActivity {

    EditText firstName;
    EditText lastName;
    EditText email;
    Button buttonNew;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_new);

        firstName = findViewById(R.id.first_name);
        lastName = findViewById(R.id.last_name);
        email = findViewById(R.id.email);
        buttonNew = findViewById(R.id.bNew);


    }
}
